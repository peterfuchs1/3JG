/**
 * 
 */
package collection;

/**
 * @author Walter Rafeiner-Magor
 *
 */
public final class Prizes {
	
	private Prizes(){}
	public static String[] prizes={
		"Holydays in New York",
		"Holydays in Korfu",
		"Holydays in Kos",
		"Holydays in Kreta",
		"Holydays in Loland",
		"Holydays in Norderney",
		"Holydays in Guernsey",
		"Holydays in Alderney",
		"Holydays in Jersey",
		"Holydays in Sark",
		"Holydays in Vienna"
	};

}
